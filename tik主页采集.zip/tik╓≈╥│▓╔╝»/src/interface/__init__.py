from ..interface.account import Account
from ..interface.account_tiktok import AccountTikTok
from ..interface.info import Info
from ..interface.info_tiktok import InfoTikTok
from ..interface.template import API
